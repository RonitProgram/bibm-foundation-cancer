import torch
import torch.nn as nn
from torch_geometric.nn.conv import GCNConv
from performer_pytorch import Performer


class BulkFormer_block(nn.Module):
    """A single BulkFormer block with graph convolution and global Performer attention."""

    def __init__(self, dim, gene_length, bin_head=4, full_head=4, bins=10, p_repeat=1):
        super().__init__()
        self.dim = dim
        self.gene_length = gene_length
        self.bins = bins
        self.p_repeat = p_repeat
        self.bin_head = bin_head
        self.full_head = full_head

        # Graph convolution over the gene graph.
        self.g = GCNConv(dim, dim, cached=True, add_self_loops=False)

        # Global attention stack.
        self.f = nn.Sequential(*[
            Performer(dim=self.dim, heads=self.full_head, depth=1,
                      dim_head=self.dim // self.full_head,
                      attn_dropout=0.05, ff_dropout=0.1)
            for _ in range(self.p_repeat)
        ])

        self.layernorm = nn.LayerNorm(self.dim)

    def forward(self, x, graph):
        # Graph message passing.
        x = self.layernorm(x)

        # When graph is a torch sparse tensor (COO/CSR), GCNConv expects a
        # 2D node feature matrix. Apply graph conv per sample for batched input.
        if torch.is_tensor(graph) and graph.layout in (torch.sparse_coo, torch.sparse_csr) and x.dim() == 3:
            gx = torch.stack([self.g(xi, graph) for xi in x], dim=0)
        else:
            gx = self.g(x, graph)

        x = x + gx

        # Global token mixing with Performer attention.
        x = self.f(x)

        return x


