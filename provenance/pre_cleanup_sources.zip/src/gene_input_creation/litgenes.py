import os 
import numpy as np 
import pandas as pd 
# import scipy.stats as stats
# from scipy.stats import pearsonr 
import matplotlib.pyplot as plt 
# import seaborn as sns 
import tarfile
import tqdm

# Load demo count data (raw count)
basic_dir = "/lustre/nvwulf/home/ronsharma/breaststuff"
X = pd.read_csv(os.path.join(basic_dir, "X.csv"), index_col=0)
X.index.name = "patient_id"
yiv = pd.read_csv(os.path.join(basic_dir, "yiv.csv"))

important_genes = pd.read_csv(os.path.join(basic_dir, "gProfiler_hsapiens_2026-07-30_17-08-56.csv"), index_col=0)
names = important_genes["converted_alias"].dropna(inplace=False)

X.columns = X.columns.str.split(".").str[0]

print("Before:", X.shape)

X = X.loc[:, ~X.columns.duplicated()]

print("After:", X.shape)
print("Duplicate columns:", X.columns.duplicated().sum())

X = X.loc[:, X.columns.isin(names)]

X.to_csv(os.path.join(basic_dir, "X_litgenes.csv"))