# Gene input creation

- hvg1000.py / hvg10000.py: reconstructed from select_hvgs_bulk in hvg.ipynb;
  rank on the stratified 80% training partition and export all samples in original
  order, using log2(x+1), to data/generated_inputs.
- create_litgenes1.py: portable version of litgenes.py using the gProfiler mapping.
- create_litgenes2.py: same membership-filtering operation, using the second set's
  Ensembl identifiers recovered from the saved X_litgenes2.csv header. It does not
  claim to reconstruct the missing original symbol-to-Ensembl mapping procedure.
- hvg.ipynb, litgenes.py, literature_signature_inspection.ipynb: historical references.

The new scripts have --input and --output options; HVG scripts also have --labels.
Generated files are separate from archived inputs. Historical script reconstruction
does not guarantee byte-identical generation of every archived matrix.
