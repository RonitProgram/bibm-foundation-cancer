# Embedding creation

The new per-input variants are in bfstuff/ and brnabertstuff/. Each has files for
hvg1000, hvg10000, litgenes and litgenes2. See provenance/reconstructed_scripts.json
for the input/output mapping and exact template provenance.

Original templates remain at this directory's top level. Variants preserve their
computational logic and change input/output names and local dependency paths.
They read the saved inputs in data/expression and write to data/generated_embeddings,
so archived arrays are not overwritten. To use newly generated gene inputs, change
the input basic_dir to data/generated_inputs after reviewing the generated inputs.

These are reconstructed scripts, not recovered historical files. The BulkRNABert
template initializes random parameters and does not load pretrained weights. The
BulkFormer template uses compatible-key checkpoint loading with the existing model
config; its active config is labeled BulkFormer-147M although the weight filename
is BulkFormer_37M.pt. That mismatch is preserved and must be resolved separately
before claiming fully pretrained embeddings. No model inference was rerun.
