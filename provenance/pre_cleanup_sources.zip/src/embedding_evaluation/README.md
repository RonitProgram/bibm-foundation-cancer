# Embedding evaluation

- brcaeval_hvg1000.py: HVG1k embedding feature selection and classification; available version caps selection at 312 coordinates.
- brcaeval_hvg10000.py: HVG10k embedding feature selection and classification; available version caps selection at 312 coordinates.
- brcaeval_litgenes.py: curated embedding classification; available version targets the second curated set.

Earlier settings used in saved reports are not separately preserved. Scripts retain original HPC paths and algorithm behavior. The conventional expression baseline remains in notebooks/classification.ipynb because it does not evaluate embeddings. The evaluation scripts select flattened embedding coordinates, not whole genes. See the root README.
