# BRCA reproducibility collection

BRCA-only collection traced backward from the two breast figures in `blresults`.
Original files outside this folder were left unchanged. This is a provenance
archive with a working figure-reproduction path, not a verified end-to-end
pretrained-model pipeline. No classifiers or embedding models were rerun.

## Folder map

- `figures/original`: the two requested breast figure files, copied unchanged.
- `src/plotting`: portable BRCA-only extraction of the original plot generator.
- `results/tables`: original metric rows used by this figure; unrelated `fs` rows removed.
- `results/raw_reports`: eight BRCA embedding evaluation reports used by the figure.
- `notebooks/classification.ipynb`: baseline code AND saved output parsed by the table builder.
- `src/gene_input_creation/hvg.ipynb`: available HVG selection reference, not a proven generator of saved embeddings.
- `src/embedding_evaluation`: embedding classification and feature-selection scripts, with original HPC paths preserved.
- `src/gene_input_creation`: HVG selection notebook and curated gene-list preparation/inspection.
- `src/embedding_creation`: available BulkFormer and BulkRNABert embedding-generation scripts.
- `data/expression`: expression matrix, labels, saved initial input matrices and mapping.
- `data/embeddings`: complete evaluation arrays only, with original subpaths retained.
- `data/model_assets`: BulkFormer weights, graph, protein embeddings and vocabulary.
- `data/selection`, `data/literature`: baseline count vector and signature supplement.
- `third_party`: only relevant model implementations and supporting metadata.
- `provenance`: file hashes, array integrity and reconstruction audit.

## Recreate the plotted figure

From this folder, run:

```powershell
python -m pip install -r requirements-plotting.txt
python src/plotting/reproduce_brca_figure.py
```

This uses saved metric tables and requires no model weights, expression data,
GPU, or large embedding arrays. Outputs go to `figures/regenerated`.
Plot labels and metric values are preserved; these are CROSS-VALIDATION MEANS,
not the separately reported held-out test metrics.

## Confirmed provenance

`blresults/figure2_breast_combined_cross_validation_metrics.png` and its key
were written by `plot_combined_results_blresults.py`, which reads
`results/tables/cv_metrics_long_by_datatype_model.csv`.
`build_grouped_results.py` constructs that table from `brcaresults_*.txt`
cross-validation means and the SAVED stream outputs of `classification.ipynb`.
It does not extract the held-out test sections for this figure.

The figure uses classification, hvg1000, hvg1k156, hvg1k312, hvg10000,
hvg10k156, hvg10k312, litgenes and litgenes2. The separate `fs.npy` embedding
baseline is NOT the plotted Standard FS baseline and was deliberately excluded.
Standard FS is the expression baseline parsed from `classification.ipynb`.

## Reproduction gaps and methods discrepancies

1. The copied yiv.csv has 1,051 labels: 1,032 zero and 19 positive. The expression
   inputs and array headers also have 1,051 samples, not the manuscript's 1,052.
   Sample-level array order cannot be verified from bare NPY files alone.
2. Two source arrays, breaststuff/hvg1000.npy and breaststuff/hvg10000.npy,
   were shorter than their NPY headers require at inspection. Source sizes were
   observed increasing, consistent with a transfer still in progress. These
   incomplete files were not duplicated. See array_integrity.json for required
   byte sizes; obtain full files from the original analysis location before rerunning.
3. Available brcaeval_hvg1000.py and brcaeval_hvg10000.py are currently configured
   for top_k_genes=312 and write hvg1k312/hvg10k312 reports. Earlier uncapped and
   156 variants are not preserved in those files. brcaeval_litgenes.py currently
   uses the second curated set. Saved reports exist for all figure configurations,
   but changing these scripts to older settings is reconstruction, not recovery.
4. Those HVG scripts flatten embeddings and select individual embedding
   coordinates using ElasticNet coefficient frequency across 100 fits
   (abs(coef)>1e-8, frequency>=80), not whole genes. Selection occurs once on
   the outer training partition BEFORE five-fold classifier cross-validation.
   Therefore selection is not refit inside each validation fold. The plot's
   labels 64/153 and top gene-count descriptions need verification against this
   implementation. The held-out test partition is excluded from those fits.
5. classification.ipynb has historical state: selection code writes sf01.txt
   using abs(coef)>0.1 but later reads selected_features.txt. The recovered count
   vector is at the source root although the notebook expects breaststuff/.
   Its plotted metrics come from saved output, not a fresh clean-kernel run.
   It also evaluates the best-recall CV fold model on held-out data rather than
   refitting the final model on the full training set. Earlier expression filters
   occur before the outer split. Do not silently rewrite these facts in Methods.
6. Available brnabert.py calls transformed_forward.init with PRNGKey(0) and does
   not load pretrained parameters. Thus this script cannot substantiate the claim
   that the saved BulkRNABert representations came from pretrained weights.
   Historical embedding generation must be checked separately.
7. Exact BRCA HVG embedding-generation scripts were not recovered by searching
   the non-hidden project code for the saved HVG input/output filenames.
   Curated generation scripts are present. The saved X_litgenes2.csv is present,
   but litgenes2.ipynb only inspects the supplementary spreadsheet and does not
   build that matrix. Original clinical archive, metadata_brca.json and
   expression_matrix.csv referenced by early classification cells were not found
   at their expected locations. The processed X.csv/yiv.csv are retained.
8. Original evaluation and generation files retain Linux/HPC paths and may require
   CUDA and model-specific dependencies. They are preserved for audit, not offered
   as portable execution entry points. Use only the plotting entry point above
   for verified reproduction. No package versions or complete training environment
   were recovered; requirements-analysis-reference.txt is an import checklist.

## Git / VS Code

Open this folder in VS Code. No Git repository was initialized and nothing was
published. Large local data/weights are excluded by .gitignore; they remain on
disk for your work. Retain third-party license notices. Inspect notebook outputs
and data provenance before choosing what to publish.

## Verification performed

All 68 table rows match freshly parsed saved reports and notebook outputs. Both regenerated figure PNGs match the originals pixel-for-pixel. Copied files were stable during copying; see provenance/validation.json. Collection size is approximately 5.32 GB.


## Added reconstructed per-input generators

src/gene_input_creation now includes hvg1000.py, hvg10000.py,
create_litgenes1.py and create_litgenes2.py. src/embedding_creation/bfstuff
and brnabertstuff each contain all four input variants. The missing historical
files described above remain missing; the newly added variants are explicitly
reconstructed from the available templates. See provenance/reconstructed_scripts.json.
No existing generation or evaluation algorithm was silently corrected. The active
BulkFormer architecture configuration also differs from the weight filename's
37M label; review checkpoint loading before making pretrained-model claims.
